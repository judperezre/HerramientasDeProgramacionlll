﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pantallas_Sistema_facturación
{
    public partial class Frmlogin : Form
    {
        public Frmlogin()
        {
            InitializeComponent();
        }

        private void materialSingleLineTextField1_Click(object sender, EventArgs e)
        {

        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private void btnValidar_Click(object sender, EventArgs e)
        {
            string respuesta = "";
            if (TxtUsuario.Text != "" && TxtPassword.Text != string.Empty)
            {
                if (TxtUsuario.Text == "Admin" && TxtPassword.Text == "123")
                    respuesta = "Juan David Pérez Restrepo";
                if (respuesta != "")
                {
                    MessageBox.Show("Bienvenido! : " + respuesta);
                    FrmPrincipal frmPrincipal = new FrmPrincipal();
                    this.Hide();
                    frmPrincipal.Show();
                }
                else
                {
                    MessageBox.Show("Usuarios y claves no encontrados");
                    TxtUsuario.Text = "";
                    TxtUsuario.Focus();
                    TxtPassword.Text = "";
                }
            }
            else 
            {
                MessageBox.Show("Debbes ingresar un usuario y una clave");
            }
        }

        private void Frmlogin_Load(object sender, EventArgs e)
        {

        }
    }
}
